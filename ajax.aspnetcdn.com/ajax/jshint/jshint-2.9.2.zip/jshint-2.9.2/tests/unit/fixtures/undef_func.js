function main () {
    function foo () {
        bar();
    }

    function bar () {
    }
}
