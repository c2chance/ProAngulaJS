/*jslint plusplus: true */

var i = 0;
++i;
