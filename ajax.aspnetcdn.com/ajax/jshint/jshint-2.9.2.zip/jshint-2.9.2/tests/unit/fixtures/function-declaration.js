export default function Header() {}

Object.defineProperty(Header, "CONST", {
  value: 1
});

export function Header() {}

Object.defineProperty(Header, "CONST", {
  value: 1
});
