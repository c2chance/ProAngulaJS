var x = {
  default: 10,
  in: 1
};

var default = 10;
function new () {}
function x(class) {}
x.default = 5;
x.in = 2;
function in() {}