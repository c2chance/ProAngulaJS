/*jslint evil: true */
/*jshint boss: true */

if (e = 1)
    doSomething();

eval('function() {}');


