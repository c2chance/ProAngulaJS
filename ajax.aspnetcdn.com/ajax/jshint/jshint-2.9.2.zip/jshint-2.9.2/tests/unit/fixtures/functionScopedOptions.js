eval("hey();");

(function () {
    /*jshint evil:true */
    eval("hey();");
}());

eval("hey();");