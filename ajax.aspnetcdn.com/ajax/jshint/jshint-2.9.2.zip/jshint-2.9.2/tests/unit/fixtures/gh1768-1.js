/*jshint undef:false*/
foo();




